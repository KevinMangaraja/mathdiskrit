<?php
$str = "Hello world!";
echo strrev($str);
?>