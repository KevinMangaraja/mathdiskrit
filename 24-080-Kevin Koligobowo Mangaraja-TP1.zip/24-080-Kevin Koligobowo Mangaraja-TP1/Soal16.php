<?php

function setHeight($minheight = 50) {
    echo "The height is : $minheight <br>";
}
setHeight();

?>