<?php

function familyName($fname) {
    echo $fname . "<br>";
}

familyName("Jani");
familyName("Hege");
familyName("Stale");
familyName("Kai Jim");
familyName("Borge");

?>