<?php
$a = "Hello World!";
$b = strpos($a, "World");

echo  $b;
?>