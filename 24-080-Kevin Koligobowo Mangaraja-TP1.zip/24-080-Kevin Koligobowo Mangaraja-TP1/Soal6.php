<?php
$txt = "W3schools.com";
echo "i love $txt !";
?>