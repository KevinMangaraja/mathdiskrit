<?php

$x = "World!";
$y = "Doly!";

echo str_replace($x, $y, "Hello World!");

?>