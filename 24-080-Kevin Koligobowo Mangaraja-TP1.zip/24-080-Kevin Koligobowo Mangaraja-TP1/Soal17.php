<?php

function sum($x, $y) {
    $z = $x + $y;
    echo "$x + $y = $z <br>";
}

sum(5, 10);
sum(7, 13);
sum(2, 4);
?>