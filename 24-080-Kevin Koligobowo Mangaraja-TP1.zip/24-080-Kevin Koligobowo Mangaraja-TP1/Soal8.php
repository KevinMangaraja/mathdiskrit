<?php
$a = "Hello World!";
echo strlen($a);
?>