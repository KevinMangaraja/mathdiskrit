<?php

$x = 5;
$y = 7;

echo $x + $y;
?>