<?php
$color = "silver";
$COLOR = "white";
print "My car is $color <br>";
printf ("My house is $COLOR");