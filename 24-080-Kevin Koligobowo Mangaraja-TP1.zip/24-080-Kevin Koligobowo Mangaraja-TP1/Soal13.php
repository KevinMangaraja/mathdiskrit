<?php

function writeMsg() {
    echo "Hello world!";
}

writeMsg();

?>