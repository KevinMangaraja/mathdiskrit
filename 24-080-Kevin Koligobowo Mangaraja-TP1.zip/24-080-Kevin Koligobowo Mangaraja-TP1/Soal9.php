<?php
$a = "Hello World!";

echo str_word_count($a);
?>