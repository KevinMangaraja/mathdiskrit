<?php
$greeting = "Hello World";
echo $greeting;
?>